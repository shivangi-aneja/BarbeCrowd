#!/bin/bash

mkdir -p ../db
mongod --dbpath ../db/
