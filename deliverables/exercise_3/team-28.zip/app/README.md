## How to Run
Instructions how to run the components can be found in the READMEs in backend/ and frontend/ respectively.


## Changelog

- 2019/06/14
  - redirect to /login if user is not logged in


## Coding Conventions

- autoformat in Visual Studio Code: (stackoverflow)[https://stackoverflow.com/questions/29973357/how-do-you-format-code-in-visual-studio-code-vscode]
